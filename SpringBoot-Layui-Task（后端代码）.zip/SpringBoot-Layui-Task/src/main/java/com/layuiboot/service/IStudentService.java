package com.layuiboot.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.layuiboot.entry.Student;
import com.layuiboot.vo.CoresJsonVo;

import java.util.List;

public interface IStudentService extends IService<Student> {
    /**
     * 查所有
     * */
    CoresJsonVo<Student> getStuByPage(int current, int size);

    /**
     * 根据条件查询
     * */
    List<Student> getByQuery(String stuId,String name,String sex,String cid);

    /**
     * 修改学生信息
     * * */
    boolean updateByStuId(Student student);

    Student getStuById(Integer id);

    boolean saveStu(Student student);

    List<Student> getStuByCId(Integer cid);

    boolean updateTaskTable(String taskTable,String title,String state);
}
