package com.layuiboot.service.impl;


import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.layuiboot.entry.Clazz;
import com.layuiboot.entry.Student;
import com.layuiboot.mapper.ClazzMapper;
import com.layuiboot.mapper.StudentMapper;
import com.layuiboot.service.IStudentService;
import com.layuiboot.vo.CoresJsonVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentServiceimpl extends ServiceImpl<StudentMapper, Student> implements IStudentService{

    @Autowired
    private StudentMapper studentMapper;

    @Autowired
    private ClazzMapper clazzMapper;

    /**
     * 分页查询
     * */
    public CoresJsonVo<Student> getStuByPage(int current, int size){
        //开启分页
        PageHelper.startPage(current,size);
        //查数据
        List<Student> students = studentMapper.selectAll();
        PageInfo<Student> info = new PageInfo<>(students);
        CoresJsonVo vo = new CoresJsonVo();
        vo.setFlag(true);
        vo.setCount(info.getPageNum());
        vo.setData(info.getList());
        return vo;
     }

    /**
     * 根据条件查询
     * 不需要用分页查询，layui页面封装好了
     * */
    @Override
    public List<Student> getByQuery(String stuId, String name,
                                           String sex, String clazzName) {
        Integer cid = null;
        if (clazzName != "" && clazzName != null){
            //先根据班级名称查出学生对应cid
            Clazz clazz = clazzMapper.selectClazzByName(clazzName);
            cid = clazz.getCid();
        }
        //查询
        List<Student> students = studentMapper.selectByQuery(stuId, name, sex, cid);
        return students;
    }

    public boolean updateByStuId(Student student) {
        //更新信息
        if (student.getClazz() != null){
            String cname = student.getClazz().getName();
            Clazz clazz = clazzMapper.selectClazzByName(cname);
            student.setClazz(clazz);
        }
        int count = studentMapper.updateByStuId(student);
        return count > 0;
    }

    @Override
    public Student getStuById(Integer id) {
        return studentMapper.selectStuById(id);
    }

    /**
     * 保存学生信息
     * */
    @Override
    public boolean saveStu(Student student) {
        Clazz clazz = clazzMapper.selectClazzByName(student.getClazz().getName());
        if (clazz == null){
            System.out.println("班级不存在，添加失败！！！");
            return false;
        }
        student.setClazz(clazz);
        int count = studentMapper.insertStu(student);
        return count > 0;
    }

    /**
     * 根据 cid 查询学生
     * */
    @Override
    public List<Student> getStuByCId(Integer cid) {
        List<Student> students = studentMapper.selectByCId(cid);
        return students;
    }

    @Override
    public boolean updateTaskTable(String taskTable,String title, String state) {
        int count = studentMapper.updateTaskTable(taskTable, title, state);
        return count > 0;
    }
}
