package com.layuiboot.service.stuservice.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.layuiboot.entry.stuentry.StudentDoTask;
import com.layuiboot.mapper.stumapper.StudentDoTaskMapper;
import com.layuiboot.service.ITaskSubmitService;
import com.layuiboot.service.stuservice.IStudentDoTaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class StudentDoTaskServiceImpl extends ServiceImpl<StudentDoTaskMapper, StudentDoTask>
                                        implements IStudentDoTaskService {

    @Autowired
    private StudentDoTaskMapper taskMapper;

    @Autowired
    private ITaskSubmitService submitService;

    @Override
    public List<StudentDoTask> getStuDotaskByTable(String taskTable) {
        List<StudentDoTask> studentDoTasks = taskMapper.selectStuDoTaskByTable(taskTable);
        return studentDoTasks;
    }

    @Override
    public List<StudentDoTask> getStuDotaskByConditon(String taskTable, String title, String state) {
        List<StudentDoTask> studentDoTasks = taskMapper.selectStuDoTaskByCondition(taskTable, title, state);
        return studentDoTasks;
    }

    @Override
    public boolean updateByStuTaskId(String taskTable,Integer id, String imgsrc) {
        int count = taskMapper.updateByStuTaskId(taskTable, id, imgsrc);
        return count > 0;
    }

    @Override
    public StudentDoTask getStuDoTaskById(String taskTable, Integer id) {
        StudentDoTask studentDoTask = taskMapper.getStuDoTaskById(taskTable, id);
        return studentDoTask;
    }

    @Override
    @Transactional
    public boolean updateTaskState(String taskTable,String stuId, String title, String content,String teacher) {
        //更新学生作业表中的信息
        int count1 = taskMapper.updatetaskState(taskTable, title,"已提交");
        //更改管理员模块中的作业提交表的信息
        boolean flag = submitService.updatetaskState(stuId, title, content,teacher);
        return flag;
    }
}
