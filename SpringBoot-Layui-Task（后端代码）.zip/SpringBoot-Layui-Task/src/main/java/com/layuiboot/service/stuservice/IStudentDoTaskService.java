package com.layuiboot.service.stuservice;

import com.baomidou.mybatisplus.extension.service.IService;
import com.layuiboot.entry.stuentry.StudentDoTask;

import java.util.List;

public interface IStudentDoTaskService extends IService<StudentDoTask> {
    List<StudentDoTask> getStuDotaskByTable(String taskTable);

    List<StudentDoTask> getStuDotaskByConditon(String taskTable, String title, String state);

    boolean updateByStuTaskId(String taskTable,Integer id, String imgsrc);

    StudentDoTask getStuDoTaskById(String taskTable, Integer id);

    boolean updateTaskState(String taskTable,String stuId, String title, String content,String teacher);
}
