package com.layuiboot.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.layuiboot.entry.Student;
import com.layuiboot.entry.Teacher;
import com.layuiboot.entry.Tid_to_Cid;
import com.layuiboot.mapper.ClazzMapper;
import com.layuiboot.mapper.StudentMapper;
import com.layuiboot.mapper.TeacherMapper;
import com.layuiboot.mapper.Tid_to_ClassNameMapper;
import com.layuiboot.service.ITeacherService;
import com.layuiboot.vo.CoresJsonVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class TeacherServiceImpl extends ServiceImpl<TeacherMapper, Teacher>
                                implements ITeacherService {

    /**/
    @Autowired
    private Tid_to_ClassNameMapper tidToClassNameMapper;

    /**/
    @Autowired
    private ClazzMapper clazzMapper;

    /**/
    @Autowired
    StudentMapper studentMapper;


    /**/
    @Override
    public List<String> getClassNameByTid(Integer tid) {
        List<Tid_to_Cid> allTidToCId = tidToClassNameMapper.selectClassNameByTid(tid);
        List<String> className=new ArrayList<>();
        for (Tid_to_Cid tidToCid :allTidToCId) {
            className.add(clazzMapper.selectClazzByid(tidToCid.getClassName()).getName());
        }
        return className;
    }

    /**/
    @Override
    public CoresJsonVo<Student> getAllStudentsByClass(Integer teacherId) {
        List<Tid_to_Cid> allTidToCId = tidToClassNameMapper.selectClassNameByTid(teacherId);
        System.out.println(allTidToCId);
        List<Student> allStudentList=new ArrayList<>();

        for (Tid_to_Cid cid :allTidToCId) {
            List<Student> students = studentMapper.selectByCId(cid.getClassName());
            System.out.println(students);
            allStudentList.addAll(students);
        }

        CoresJsonVo vo = new CoresJsonVo();

        vo.setData(allStudentList);
        vo.setCount(10);
        vo.setFlag(true);


        return vo;
    }
}
