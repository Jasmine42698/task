package com.layuiboot.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.layuiboot.entry.LoginUser;
import com.layuiboot.entry.SessionEntry;
import com.layuiboot.mapper.SessionEntryMapper;

public interface ISessionEntryService extends IService<SessionEntry> {
    /**
     * 根据用户名，密码查询用户信息
     */

    SessionEntry selectSessionEntry(String tableName,LoginUser entry);

    boolean updateSionById(String adminTable, SessionEntry sessionEntry);

    boolean updatePasByid(String tableName, String password,Integer id);
}
