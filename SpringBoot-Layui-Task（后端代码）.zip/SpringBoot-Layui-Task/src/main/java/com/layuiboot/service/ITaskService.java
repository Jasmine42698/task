package com.layuiboot.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.layuiboot.entry.Task;

public interface ITaskService extends IService<Task> {
}
