package com.layuiboot.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.layuiboot.entry.Admin;

public interface IAdminService extends IService<Admin> {
}
