package com.layuiboot.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.layuiboot.entry.Clazz;
import com.layuiboot.entry.Student;
import com.layuiboot.entry.Task;
import com.layuiboot.entry.TaskSubmit;
import com.layuiboot.mapper.ClazzMapper;
import com.layuiboot.mapper.TaskMapper;
import com.layuiboot.mapper.TaskSubmitMapper;
import com.layuiboot.service.IStudentService;
import com.layuiboot.service.ITaskSubmitService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
public class TaskSubmitServiceImpl extends ServiceImpl<TaskSubmitMapper, TaskSubmit>
                                    implements ITaskSubmitService {

    @Autowired
    private TaskSubmitMapper submitMapper;

    @Autowired
    private IStudentService studentService;

    /**/
    @Autowired
    private TaskSubmitMapper taskSubmitMapper;

    /**/
    @Autowired
    private ClazzMapper clazzMapper;

    /**/
    @Autowired
    private TaskMapper taskMapper;

    @Override
    @Transactional          //进行业务回滚
    public boolean updateTaskSubById(TaskSubmit taskSubmit) {
        //先更改作业提交信息
        boolean flag = updateById(taskSubmit);
        //再更改学生作业表的提交状态,这里根据学号查询，实际上查到的只有一个学生
        List<Student> students = studentService.getByQuery(taskSubmit.getStuId(), null, null, null);
        Student student = students.get(0);
        //得到学生作业表的表名，进行表的修改
        String taskTable = student.getTaskTable();
        if (taskTable != null && taskTable != ""){
            studentService.updateTaskTable(taskTable,taskSubmit.getTitle(),taskSubmit.getState());
        }
        return flag;
    }

    /**
     * 修改
     * */
    @Override
    public boolean updatetaskState(String stuId, String title, String content,String teacher) {
        int count = submitMapper.updatetaskState(stuId, title, content,teacher);
        return count > 0;
    }

    /**/
    @Override
    public List<TaskSubmit> selectTaskByClassName(List<String> classNames) {
        List<TaskSubmit> taskList=new ArrayList<>();
        for (String className:classNames) {
            taskList.addAll(taskSubmitMapper.selectTaskByClazzName(className));
        }
        return taskList;
    }

    /**/
    @Override
    public boolean addWork(TaskSubmit taskSubmit) {
        //TaskSubmit(id=null, title=111, require=111, teacher=null, clazz=高三3班, startTime=2024-06-28 00:00:00,
        // endTime=2024-06-29 00:00:00, stuId=null, student=null, content=111, state=null)

        Task task = new Task(null, taskSubmit.getTitle(), taskSubmit.getRequre(),taskSubmit.getStartTime(),taskSubmit.getEndTime(),taskSubmit.getTeacher(),taskSubmit.getClazz());
        taskMapper.insert(task);
        int temp=0;
        //通过班级名字获取cid
        Clazz clazz = clazzMapper.selectClazzByName(taskSubmit.getClazz());
        //通过cid获取学生信息
        List<Student> stuByCId = studentService.getStuByCId(clazz.getCid());
        for (Student student:stuByCId) {
            taskSubmit.setStuId(student.getStuId());
            taskSubmit.setStudent(student.getName());
            taskSubmit.setState("未提交");
            taskSubmitMapper.addTask(taskSubmit);
            temp++;
        }
        if (temp<stuByCId.size()){
            return false;
        }
        return true;
    }
}
