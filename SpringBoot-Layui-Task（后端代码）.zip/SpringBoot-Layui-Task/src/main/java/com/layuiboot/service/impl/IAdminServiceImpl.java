package com.layuiboot.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.layuiboot.entry.Admin;
import com.layuiboot.mapper.AdminMapper;
import com.layuiboot.service.IAdminService;
import org.springframework.stereotype.Service;

@Service
public class IAdminServiceImpl extends ServiceImpl<AdminMapper, Admin>
                                implements IAdminService {
}
