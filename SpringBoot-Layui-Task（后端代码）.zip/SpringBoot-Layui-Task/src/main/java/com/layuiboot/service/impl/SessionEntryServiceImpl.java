package com.layuiboot.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.layuiboot.entry.LoginUser;
import com.layuiboot.entry.SessionEntry;
import com.layuiboot.mapper.SessionEntryMapper;
import com.layuiboot.service.ISessionEntryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SessionEntryServiceImpl extends ServiceImpl<SessionEntryMapper,SessionEntry>
                            implements ISessionEntryService {

    @Autowired
    private SessionEntryMapper mapper;

    @Override
    public SessionEntry selectSessionEntry(String tableName,LoginUser entry) {
        SessionEntry sessionEntry = mapper.selectSessionEntry(tableName, entry.getUserName(), entry.getPassword());
        return sessionEntry;
    }

    @Override
    public boolean updateSionById(String adminTable, SessionEntry sessionEntry) {
        int count = mapper.updateSionByid(adminTable, sessionEntry.getId(), sessionEntry.getName());
        return count > 0;
    }

    @Override
    public boolean updatePasByid(String tableName, String password, Integer id) {
        int count = mapper.updatePasByid(tableName, id, password);
        return count > 0;
    }


}
