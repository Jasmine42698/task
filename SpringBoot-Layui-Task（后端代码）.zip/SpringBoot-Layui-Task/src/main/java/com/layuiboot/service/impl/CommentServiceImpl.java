package com.layuiboot.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.layuiboot.entry.Comment;
import com.layuiboot.mapper.CommentMapper;
import com.layuiboot.service.ICommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CommentServiceImpl extends ServiceImpl<CommentMapper, Comment>
                                        implements ICommentService {

    @Autowired
    private CommentMapper commentMapper;

    @Override
    public boolean updateCommentById(Integer id, Double score) {
        System.out.println("======" + score);
        int count = commentMapper.updateCommentById(id, score);
        return count > 0;
    }

    /**/
    @Override
    public Boolean addComment(Comment comment) {
        if (commentMapper.addComment(comment)==0){
            return false;
        }
        return true;
    }
}
