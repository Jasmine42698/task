package com.layuiboot.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.layuiboot.entry.Clazz;
import com.layuiboot.mapper.ClazzMapper;
import com.layuiboot.service.IClazzService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ClazzServiceImpl extends ServiceImpl<ClazzMapper, Clazz> implements IClazzService{

    @Autowired
    private ClazzMapper mapper;

    @Override
    public boolean updateClazzById(Clazz clazz){
        int count = mapper.updateClazzById(clazz);
        return count > 0;
    }

    @Override
    public boolean deleteByclazzId(Integer cid) {
        int count = mapper.deleteClazzById(cid);
        return count > 0;
    }
}
