package com.layuiboot.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.layuiboot.entry.Comment;

public interface ICommentService extends IService<Comment> {
    boolean updateCommentById(Integer id, Double score);

    /**/
    Boolean addComment(Comment comment);
}
