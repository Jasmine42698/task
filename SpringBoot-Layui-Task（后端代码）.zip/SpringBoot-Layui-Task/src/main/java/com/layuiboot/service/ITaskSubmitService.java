package com.layuiboot.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.layuiboot.entry.TaskSubmit;

import java.util.List;

public interface ITaskSubmitService extends IService<TaskSubmit> {
    boolean updateTaskSubById(TaskSubmit taskSubmit);

    boolean updatetaskState(String stuId, String title, String content,String teacher);

    /**/
    List<TaskSubmit> selectTaskByClassName(List<String> className);

    /**/
    boolean addWork(TaskSubmit taskSubmit);
}
