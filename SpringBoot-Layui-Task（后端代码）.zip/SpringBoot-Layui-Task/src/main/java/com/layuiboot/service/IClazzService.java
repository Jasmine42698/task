package com.layuiboot.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.layuiboot.entry.Clazz;

public interface IClazzService extends IService<Clazz>{

    boolean updateClazzById(Clazz clazz);

    boolean deleteByclazzId(Integer cid);
}
