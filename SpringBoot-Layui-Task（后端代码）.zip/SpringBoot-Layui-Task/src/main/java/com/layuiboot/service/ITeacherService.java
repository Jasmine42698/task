package com.layuiboot.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.layuiboot.entry.Student;
import com.layuiboot.entry.Teacher;
import com.layuiboot.vo.CoresJsonVo;

import java.util.List;

public interface ITeacherService extends IService<Teacher> {

    /**/
    List<String> getClassNameByTid(Integer tid);

    /**/
    CoresJsonVo<Student> getAllStudentsByClass(Integer key);
}
