package com.layuiboot.utils;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.util.UUID;

@Component
public class LoadFileUtil {

    private static String path;

    @Value("${file.path}")
    public void setPath(String path) {
        this.path = path;
    }

    //生成文件名
    public static String randomSrc(String fileName) {
        String name = "";
        String pifex = fileName.substring(fileName.indexOf("."));
        String uid = UUID.randomUUID().toString();
        name = uid.substring(0,7) + pifex;
        return name;
    }

    //文件上传
    public static String loadFile(MultipartFile file){
        //文件名称
        String originalFilename = file.getOriginalFilename();
        //新的文件名称
        String fileName = randomSrc(originalFilename);
        //创建目录
        File newfile = new File(path);
        if (!newfile.exists()){
            newfile.mkdirs();
        }
        InputStream is = null;
        BufferedInputStream bis = null;
        OutputStream os = null;
        BufferedOutputStream bos = null;
        try {
            is = file.getInputStream();
            bis = new BufferedInputStream(is);
            os = new FileOutputStream(path + "/" + fileName);
            bos = new BufferedOutputStream(os);
            byte[] bytes = new byte[1024*100];
            int len = -1;
            //上传文件
            while ((len = bis.read(bytes)) != -1){
                bos.write(bytes,0,len);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }finally {
             try {
                 bis.close();
                 bos.close();
             }catch (Exception e){
                 e.printStackTrace();
             }
        }
        //返回新的文件名称
        return fileName;
    }

    //删除文件
    public static void deleteFile(String fileName){
        if (fileName != "") {
            String drc = path + "/" + fileName;
            File file = new File(drc);
            if (file.exists()) {
                file.delete();
            }
        }
    }

}
