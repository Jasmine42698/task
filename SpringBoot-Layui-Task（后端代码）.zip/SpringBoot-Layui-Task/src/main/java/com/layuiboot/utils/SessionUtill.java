package com.layuiboot.utils;

import com.layuiboot.entry.IndenTity;
import com.layuiboot.entry.SessionEntry;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

@Component
public class SessionUtill {

    //往缓存数据
    @CachePut(value = "session",key = "#key")
    public SessionEntry setSessionEntry(String key , SessionEntry sessionEntry){
        return sessionEntry;
    }

    //往缓存取数据
    @Cacheable(value = "session",key = "#key")
    public SessionEntry getSessionEntry(String key){
        return null;
    }

    //删除缓存
    @CacheEvict(cacheNames = "session",key = "#key")
    public void deleteSessionEntry(String key){
        System.out.println("删除缓存");
    }

}
