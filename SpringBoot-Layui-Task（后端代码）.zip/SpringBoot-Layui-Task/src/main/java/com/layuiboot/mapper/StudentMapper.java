package com.layuiboot.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.layuiboot.entry.Student;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface StudentMapper extends BaseMapper<Student> {
    /**
     * 查询所有，采用分步查询
     * */
    List<Student> selectAll();

    /**
     * 根据条件查询
     * */
    List<Student> selectByQuery(@Param("stuId") String stuId,
                                @Param("name") String name,
                                @Param("sex") String sex,
                                @Param("cid") Integer cid);

    int updateByStuId(Student student);


    Student selectStuById(Integer id);

    int insertStu(Student student);

    List<Student> selectByCId(Integer cid);

    int updateTaskTable(@Param("taskTable") String taskTable,
                        @Param("title") String title,
                        @Param("state") String state);
}
