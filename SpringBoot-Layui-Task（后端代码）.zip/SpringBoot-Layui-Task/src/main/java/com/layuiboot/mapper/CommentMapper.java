package com.layuiboot.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.layuiboot.entry.Comment;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface CommentMapper extends BaseMapper<Comment> {
    int updateCommentById(@Param("id") Integer id, @Param("score") Double score);

    /**/
    @Insert("insert into tu_comment values(null,#{teacher},#{title},#{student},#{score},#{comment})")
    int addComment(Comment comment);
}
