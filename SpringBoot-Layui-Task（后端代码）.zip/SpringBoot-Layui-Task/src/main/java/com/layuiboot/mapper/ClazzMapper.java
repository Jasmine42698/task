package com.layuiboot.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.layuiboot.entry.Clazz;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ClazzMapper extends BaseMapper<Clazz> {

    Clazz selectClazzByid(Integer id);

    Clazz selectClazzByName(String clazzName);


    int updateClazzById(Clazz clazz);

    int deleteClazzById(Integer cid);
}
