package com.layuiboot.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.layuiboot.entry.TaskSubmit;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.Collection;
import java.util.List;

@Mapper
public interface TaskSubmitMapper extends BaseMapper<TaskSubmit> {
    int updatetaskState(@Param("stuId") String stuId,
                        @Param("title") String title,
                        @Param("content") String content,
                        @Param("teacher") String teacher);

    /**/
    @Select("select * from tu_submit where clazz=#{className}")
    List<TaskSubmit> selectTaskByClazzName(@Param("className") String classname);

    /**/
    @Insert("insert into tu_submit values(null,#{taskSubmit.title},#{taskSubmit.requre},#{taskSubmit.teacher},#{taskSubmit.clazz},#{taskSubmit.startTime},#{taskSubmit.endTime},#{taskSubmit.content},#{taskSubmit.stuId},#{taskSubmit.student},#{taskSubmit.state})")
    int addTask(@Param("taskSubmit") TaskSubmit taskSubmit);
}
