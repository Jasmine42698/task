package com.layuiboot.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.layuiboot.entry.SessionEntry;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface SessionEntryMapper extends BaseMapper<SessionEntry> {

    SessionEntry selectSessionEntry(@Param("tableName") String tableName,
                                    @Param("name") String name,
                                    @Param("password") String password);

    int updateSionByid(@Param("tableName")String adminTable, @Param("id") Integer id,
                       @Param("name") String name);

    int updatePasByid(@Param("tableName") String tableName, @Param("id") Integer id,
                      @Param("password")String password);
}
