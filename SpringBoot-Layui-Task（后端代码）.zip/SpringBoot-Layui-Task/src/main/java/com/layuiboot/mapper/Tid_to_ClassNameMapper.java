package com.layuiboot.mapper;

import com.layuiboot.entry.Tid_to_Cid;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;


/**/

@Mapper
public interface Tid_to_ClassNameMapper {
    @Select("select * from teacher_to_class where teacherId=#{tid}")
    List<Tid_to_Cid> selectClassNameByTid(@Param("tid") Integer tid);
}
