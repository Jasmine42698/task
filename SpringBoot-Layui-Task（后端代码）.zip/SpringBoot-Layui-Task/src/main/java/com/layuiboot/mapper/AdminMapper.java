package com.layuiboot.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.layuiboot.entry.Admin;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface AdminMapper extends BaseMapper<Admin> {
}
