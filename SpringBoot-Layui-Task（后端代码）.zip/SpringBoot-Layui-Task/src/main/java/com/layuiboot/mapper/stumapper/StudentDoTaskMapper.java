package com.layuiboot.mapper.stumapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.layuiboot.entry.stuentry.StudentDoTask;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface StudentDoTaskMapper extends BaseMapper<StudentDoTask> {

    List<StudentDoTask> selectStuDoTaskByTable(String taskTable);

    List<StudentDoTask> selectStuDoTaskByCondition(String taskTable, String title, String state);

    int updateByStuTaskId(@Param("taskTable") String taskTable,
                          @Param("id") Integer id,
                          @Param("imgsrc") String imgsrc);

    StudentDoTask getStuDoTaskById(@Param("taskTable") String taskTable,
                                   @Param("id") Integer id);

    int updatetaskState(@Param("taskTable") String taskTable,
                        @Param("title") String title,
                        @Param("state")String state);
}
