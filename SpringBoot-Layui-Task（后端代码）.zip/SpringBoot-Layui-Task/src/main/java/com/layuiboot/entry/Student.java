package com.layuiboot.entry;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 学生类
 * */
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("tu_student")
public class Student {
    private Integer id;
    private String stuId;
    private String name;
    private String head;
    private String sex;
    private String phone;
    private Clazz clazz;
    private String taskTable;

    public Student(Integer id, String stuId, String name, String head, String sex, String phone, Clazz clazz) {
        this.id = id;
        this.stuId = stuId;
        this.name = name;
        this.head = head;
        this.sex = sex;
        this.phone = phone;
        this.clazz = clazz;
    }
}
