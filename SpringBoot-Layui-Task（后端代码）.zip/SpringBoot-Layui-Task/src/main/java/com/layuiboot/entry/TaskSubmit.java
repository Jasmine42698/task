package com.layuiboot.entry;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 *作业信息提交 类
 * */
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("tu_submit")
public class TaskSubmit {
    private Integer id;
    private String title;
    private String requre;
    private String teacher;
    private String clazz;
    private String startTime;
    private String endTime;
    private String stuId;
    private String student;
    private String content;
    private String state;
}
