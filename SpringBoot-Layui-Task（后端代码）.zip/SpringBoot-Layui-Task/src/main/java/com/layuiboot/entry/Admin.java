package com.layuiboot.entry;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 管理员类
 * */
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("tu_admin")
public class Admin {
    private Integer id;
    private String name;
    private String sex;
    private Integer age;
    private String phone;
    private String head;
    private String email;
    private String snapshot;

}
