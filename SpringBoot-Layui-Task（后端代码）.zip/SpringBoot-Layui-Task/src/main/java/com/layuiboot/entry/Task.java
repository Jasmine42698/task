package com.layuiboot.entry;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * 作业信息类
 * */
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("tu_task")
public class Task {
    private Integer id;
    private String title;
    private String requre;
    private String startTime;
    private String endTime;
    private String teacher;
    private String clazz;
}
