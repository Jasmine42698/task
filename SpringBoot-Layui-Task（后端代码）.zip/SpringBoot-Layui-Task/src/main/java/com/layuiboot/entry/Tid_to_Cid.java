package com.layuiboot.entry;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**/

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Tid_to_Cid {
    private Integer teacherId;
    private Integer className;
}
