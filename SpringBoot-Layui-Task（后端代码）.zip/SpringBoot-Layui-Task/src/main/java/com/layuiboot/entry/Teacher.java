package com.layuiboot.entry;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 教师类
*/
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("tu_teacher")
public class Teacher {
    private Integer id;
    private String name;
    private String sex;
    private Integer age;
    private String head;
    private String phone;
    private String email;
    private String clazz;
}
