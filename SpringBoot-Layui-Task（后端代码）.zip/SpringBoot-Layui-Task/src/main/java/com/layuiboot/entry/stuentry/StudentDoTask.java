package com.layuiboot.entry.stuentry;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class StudentDoTask {

    private Integer id;
    private String title;
    private String requre;
    private String startTime;
    private String endTime;
    private String teacher;
    private String content;
    private String state;
}
