package com.layuiboot.entry;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/*
* 用于接收登录对象
* */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LoginUser {
    private String userName;
    private String password;
    private String identity;
}
