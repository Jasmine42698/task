package com.layuiboot.entry;


/**
 * 常量类
 * */
public class IndenTity {

    public static final String ADMIN = "admin";
    public static final String STUDENT = "student";
    public static final String TEACHER = "teacher";
    public static final String ADMIN_TABLE = "tu_lg_admin";
    public static final String STUDENT_TABLE = "tu_lg_student";
    public static final String TEACHER_TABLE = "tu_lg_teacher";

    public static final String SESSIO_NENTRY = "sessionEntry";

}
