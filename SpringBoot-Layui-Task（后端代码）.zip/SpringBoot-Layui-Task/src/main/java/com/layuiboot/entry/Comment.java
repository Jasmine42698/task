package com.layuiboot.entry;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("tu_comment")
public class Comment {
    private Integer id;
    private String teacher;
    private String title;
    private String student;
    private Double score;
    private String comment;
}
