package com.layuiboot.entry;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * 班级类
 * */
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("tu_clazz")
public class Clazz {
    private Integer cid;
    private String name;
}
