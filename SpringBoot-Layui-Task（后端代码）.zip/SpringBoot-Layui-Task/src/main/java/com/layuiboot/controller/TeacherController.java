package com.layuiboot.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.layuiboot.entry.*;
import com.layuiboot.service.ITeacherService;
import com.layuiboot.service.impl.ClazzServiceImpl;
import com.layuiboot.utils.LoadFileUtil;
import com.layuiboot.utils.SessionUtill;
import com.layuiboot.vo.CoresJsonVo;
import com.layuiboot.vo.LayUiVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("/teacher")
public class TeacherController {

    @Autowired
    private ITeacherService teacherService;

    @Autowired
    private ClazzServiceImpl clazzService;

    /**/
    @Autowired
    private SessionUtill sessionUtill;

    /**/
    @GetMapping("/getTeacherAdminClass")
    public List<String> getTeacherAdminClass(){
        //从缓存拿到教师id
        SessionEntry sessionEntry = sessionUtill.getSessionEntry(IndenTity.SESSIO_NENTRY);
        return teacherService.getClassNameByTid(sessionEntry.getKey());

    }

    /**/
    @RequestMapping("/selectStuByTeacherId")
    public CoresJsonVo<Student> selectStuByTeacherId(){
        SessionEntry sessionEntry = sessionUtill.getSessionEntry(IndenTity.SESSIO_NENTRY);
        return teacherService.getAllStudentsByClass(sessionEntry.getKey());
    }



    /**
     * 查询所有
     * */

    @GetMapping
    public LayUiVo<Teacher> getTeachers(){
        List<Teacher> teachers = teacherService.list();
        LayUiVo<Teacher> vo = new LayUiVo<>();
        vo.setData(teachers);
        return vo;
    }

    /**
     * 根据条件查询
     * */
    @GetMapping("/condition")
    public CoresJsonVo<Teacher> getTeachersByCondition(@RequestParam("name")String name,
                                                       @RequestParam("clazz")String clazz){
        QueryWrapper<Teacher> wrapper = new QueryWrapper<>();
        if(name != "") {
            wrapper.eq("name", name);
        }
        if (clazz != ""){
            wrapper.eq("clazz",clazz);
        }
        List<Teacher> teachers = teacherService.list(wrapper);
        CoresJsonVo<Teacher> vo = new CoresJsonVo<>();
        vo.setData(teachers);
        vo.setFlag(teachers.size() > 0);
        return vo;
    }

    /**
     * 删除
     * */
    @DeleteMapping("/{id}")
    public CoresJsonVo<Teacher> removeTeacherByid(@PathVariable("id")Integer id){
        boolean flag = teacherService.removeById(id);
        CoresJsonVo<Teacher> vo = new CoresJsonVo<>();
        vo.setFlag(flag);
        return vo;
    }

    /**
     * 批量删除
     * */
    @DeleteMapping("/deleteByIds")
    public CoresJsonVo<Teacher> removeTeacherByids(@RequestParam("ids")String ids,
                                                    @RequestParam("imgs")String imgs){
        System.out.println(ids);
        String[] imgsary = imgs.split(",");
        String[] idsary = ids.split(",");
        List<String> idsList = Arrays.asList(idsary);
        boolean flag = teacherService.removeByIds(idsList);
        for (String imgsrc : imgsary) {
            LoadFileUtil.deleteFile(imgsrc);
        }
        CoresJsonVo<Teacher> vo = new CoresJsonVo<>();
        vo.setFlag(flag);
        return vo;
    }

    /**
     * 添加
     * */
    @PostMapping
    public CoresJsonVo<Teacher> addTeacher(@RequestBody Teacher teacher){
        CoresJsonVo<Teacher> vo = new CoresJsonVo<>();
        QueryWrapper<Clazz> wrapper = new QueryWrapper<>();
        wrapper.eq("name",teacher.getClazz());
        Clazz clazz = clazzService.getOne(wrapper);
        if (clazz == null){
            vo.setFlag(false);
            return vo;
        }
        boolean flag = teacherService.save(teacher);
        vo.setFlag(flag);
        return vo;
    }

    /**
     * 修改
     * */
    @PutMapping
    public CoresJsonVo<Teacher> updateTeacherByid(@RequestBody Teacher teacher){
        Teacher oldTeacher = teacherService.getById(teacher.getId());
        if (oldTeacher.getHead() != "" && !oldTeacher.getHead().equals(teacher.getHead())){
            LoadFileUtil.deleteFile(oldTeacher.getHead());
        }
        boolean flag = teacherService.updateById(teacher);
        CoresJsonVo<Teacher> vo = new CoresJsonVo<>();
        vo.setFlag(flag);
        return vo;
    }
}
