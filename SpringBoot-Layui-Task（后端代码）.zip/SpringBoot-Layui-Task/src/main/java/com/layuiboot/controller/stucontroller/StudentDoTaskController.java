package com.layuiboot.controller.stucontroller;

import com.layuiboot.entry.stuentry.StudentDoTask;
import com.layuiboot.service.stuservice.IStudentDoTaskService;
import com.layuiboot.entry.IndenTity;
import com.layuiboot.entry.SessionEntry;
import com.layuiboot.entry.Student;
import com.layuiboot.service.IStudentService;
import com.layuiboot.utils.LoadFileUtil;
import com.layuiboot.utils.SessionUtill;
import com.layuiboot.vo.CoresJsonVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("stuDoTask")
public class StudentDoTaskController {

    @Autowired
    private IStudentDoTaskService taskService;

    @Autowired
    private SessionUtill sessionUtill;

    @Autowired
    private IStudentService studentService;

    /**
     * 根据当前登录对象查询作业信息
     * */
    @GetMapping
    private CoresJsonVo<StudentDoTask> getStuDoTasks(){
        //获取当前登录的对象
        SessionEntry sessionEntry = sessionUtill.getSessionEntry(IndenTity.SESSIO_NENTRY);
        //根据id获取对应身份信息
        Student student = studentService.getStuById(sessionEntry.getKey());
        //获取学生对应的作业表
        String taskTable = student.getTaskTable();
        //到对应作业表查询作业
        List<StudentDoTask> taskList = taskService.getStuDotaskByTable(taskTable);
        CoresJsonVo<StudentDoTask> vo = new CoresJsonVo<>();
        vo.setFlag(taskList.size() > 0);
        vo.setData(taskList);
        return vo;
    }

    /**
     * 根据当前登录对象 按条件查询作业信息
     * */
    @GetMapping("/condition")
    public CoresJsonVo<StudentDoTask> getStuDoTasksByCondition(@RequestParam("title") String title,
                                                               @RequestParam("state") String state){
        //获取当前登录的对象
        SessionEntry sessionEntry = sessionUtill.getSessionEntry(IndenTity.SESSIO_NENTRY);
        //根据id获取对应身份信息
        Student student = studentService.getStuById(sessionEntry.getKey());
        //获取学生对应的作业表
        String taskTable = student.getTaskTable();
        //到对应作业表查询作业
        List<StudentDoTask> studentDoTaskList = taskService.getStuDotaskByConditon(taskTable, title, state);
        CoresJsonVo<StudentDoTask> vo = new CoresJsonVo<>();
        vo.setFlag(studentDoTaskList.size() > 0);
        vo.setData(studentDoTaskList);
        return vo;
    }


    /**
     * 上传作业信息
     * */
    @PutMapping
    public CoresJsonVo<StudentDoTask> updateStuDoTask(@RequestParam("id") Integer id,
                                                      @RequestParam("imgsrc") String imgsrc){
        //获取当前登录的对象
        SessionEntry sessionEntry = sessionUtill.getSessionEntry(IndenTity.SESSIO_NENTRY);
        //根据id获取对应身份信息
        Student student = studentService.getStuById(sessionEntry.getKey());
        //获取学生对应的作业表
        String taskTable = student.getTaskTable();
        StudentDoTask studentDoTask = taskService.getStuDoTaskById(taskTable, id);
        if (studentDoTask.getContent() != ""){
            LoadFileUtil.deleteFile(studentDoTask.getContent());
        }
        boolean flag = false;
        if (imgsrc != ""){
            flag = taskService.updateByStuTaskId(taskTable, id, imgsrc);
        }
        CoresJsonVo<StudentDoTask> vo = new CoresJsonVo<>();
        vo.setFlag(flag);
        return vo;
    }

    /**
     * 提交作业
     * */
    @PostMapping
    public CoresJsonVo<StudentDoTask> submitTask(@RequestParam("title")String title,
                                                 @RequestParam("content")String content,
                                                 @RequestParam("teacher")String teacher){
        //获取当前登录的对象
        SessionEntry sessionEntry = sessionUtill.getSessionEntry(IndenTity.SESSIO_NENTRY);
        //根据id获取对应身份信息
        Student student = studentService.getStuById(sessionEntry.getKey());
        String stuId = student.getStuId();
        //获取学生对应的作业表
        String taskTable = student.getTaskTable();
        //更改tu_submit表的信息
        boolean flag = taskService.updateTaskState(taskTable, stuId,title, content,teacher);
        CoresJsonVo<StudentDoTask> vo = new CoresJsonVo<>();
        vo.setFlag(flag);
        return vo;
    }

}
