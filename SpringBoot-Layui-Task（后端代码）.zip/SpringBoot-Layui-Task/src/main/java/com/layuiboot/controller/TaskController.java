package com.layuiboot.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.layuiboot.entry.Task;
import com.layuiboot.service.ITaskService;
import com.layuiboot.vo.CoresJsonVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/task")
public class TaskController {

    @Autowired
    private ITaskService taskService;

    /**
     * 查所有
     */
    @GetMapping
    public CoresJsonVo<Task> getTasks() {
        List<Task> tasks = taskService.list();
        CoresJsonVo<Task> vo = new CoresJsonVo<>();
        vo.setFlag(true);
        vo.setData(tasks);
        return vo;
    }

    /**
     * 按条件查询
     */
    @GetMapping("/condition")
    public CoresJsonVo<Task> getTakesByCondition(@RequestParam("title") String title,
                                                 @RequestParam("clazz") String clazz,
                                                 @RequestParam("startTime") String startTime,
                                                 @RequestParam("endTime") String endtTime) {
        QueryWrapper<Task> wrapper = new QueryWrapper<>();
        wrapper = title != "" ? wrapper.eq("title", title) : wrapper;
        wrapper = clazz != "" ? wrapper.eq("clazz", clazz) : wrapper;
        //
        wrapper.apply(startTime != "",
                        "date_format (start_time,'%Y-%m-%d %H:%i:%s') >= date_format ('" + startTime + "','%Y-%m-%d %H:%i:%s')")
                .apply(endtTime != "",
                        "date_format (end_time,'%Y-%m-%d %H:%i:%s') <= date_format ('" + endtTime + "','%Y-%m-%d %H:%i:%s')");
        List<Task> tasks = taskService.list(wrapper);
        CoresJsonVo<Task> vo = new CoresJsonVo<>();
        vo.setFlag(tasks.size() > 0);
        vo.setData(tasks);
        return vo;
    }

    /**
     * 删除
     */
    @DeleteMapping("/{id}")
    public CoresJsonVo<Task> removeById(@PathVariable("id") Integer id){
        boolean flag = taskService.removeById(id);
        CoresJsonVo<Task> vo = new CoresJsonVo<>();
        vo.setFlag((flag));
        return vo;
    }

    /**
     * 添加
     */
    @PostMapping()
    public CoresJsonVo<Task> addTask(@RequestBody Task task) {
        boolean flag = taskService.save(task);
        CoresJsonVo<Task> vo = new CoresJsonVo<>();
        vo.setFlag(flag);
        return vo;
    }

    /**
     * 修改
     */
    @PutMapping
    public CoresJsonVo<Task> updateByid(@RequestBody Task task) {
        boolean flag = taskService.updateById(task);
        CoresJsonVo<Task> vo = new CoresJsonVo<>();
        vo.setFlag(flag);
        return vo;
    }
}
