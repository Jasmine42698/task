package com.layuiboot.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.layuiboot.entry.IndenTity;
import com.layuiboot.entry.TaskSubmit;
import com.layuiboot.service.ITaskSubmitService;
import com.layuiboot.utils.SessionUtill;
import com.layuiboot.vo.CoresJsonVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("taskSubmit")
public class TaskSubmitController {

    @Autowired
    private ITaskSubmitService submitService;

    /**/
    @Autowired
    private SessionUtill sessionUtill;

    /**/
    @PostMapping("/selectTaskSubmit")
    public List<TaskSubmit> selectTaskSubmit(@RequestBody List<String> clazzNames){
        return submitService.selectTaskByClassName(clazzNames);

    }

    /**/
    @PostMapping("/addWork")
    public Boolean addWork(@RequestBody TaskSubmit taskSubmit){
        System.out.println(taskSubmit);
        taskSubmit.setTeacher(sessionUtill.getSessionEntry(IndenTity.SESSIO_NENTRY).getName());
        return submitService.addWork(taskSubmit);
    }



    /**
     * 查所有
     * */
    @GetMapping
    public CoresJsonVo<TaskSubmit> getTaskSubmits(){
        List<TaskSubmit> taskSubmits = submitService.list();
        CoresJsonVo<TaskSubmit> vo = new CoresJsonVo<>();
        vo.setFlag(taskSubmits.size() > 0);
        vo.setData(taskSubmits);
        return vo;
    }

    /**
     * 根据条件查询
     * */
    @GetMapping("/condition")
    public CoresJsonVo<TaskSubmit> getTaskSubmitsByCondition(@RequestParam("title")String title,
                                                             @RequestParam("clazz")String clazzName,
                                                             @RequestParam("student")String studentName,
                                                             @RequestParam("state")String state){
        //写具体查询业务
        QueryWrapper<TaskSubmit> wrapper = new QueryWrapper<>();
        wrapper = title != "" ? wrapper.eq("title",title) : wrapper;
        wrapper = clazzName != "" ? wrapper.eq("clazz",clazzName) : wrapper;
        wrapper = studentName != "" ? wrapper.eq("student",studentName) : wrapper;
        wrapper = state != "" ? wrapper.eq("state",state) : wrapper;
        List<TaskSubmit> taskSubmits = submitService.list(wrapper);
        CoresJsonVo<TaskSubmit> vo = new CoresJsonVo<>();
        vo.setFlag(taskSubmits.size() > 0);
        vo.setData(taskSubmits);
        return vo;
    }

    /**
     * 添加
     * */
    @PostMapping
    public CoresJsonVo<TaskSubmit> addTaskSubmit(@RequestBody TaskSubmit taskSubmit){
        boolean flag = submitService.save(taskSubmit);
        CoresJsonVo<TaskSubmit> vo = new CoresJsonVo<>();
        vo.setFlag(flag);
        return vo;
    }

    /**
     * 刪除
     * */
    @DeleteMapping("/{id}")
    public CoresJsonVo<TaskSubmit> removeById(@PathVariable("id")Integer id){
        boolean flag = submitService.removeById(id);
        CoresJsonVo<TaskSubmit> vo = new CoresJsonVo<>();
        vo.setFlag(flag);
        return vo;
    }

    /**
     * 修改
     * */
    @PutMapping
    public CoresJsonVo<TaskSubmit> updateById(@RequestBody TaskSubmit taskSubmit){
        System.out.println(taskSubmit);
        boolean flag = submitService.updateTaskSubById(taskSubmit);
        CoresJsonVo<TaskSubmit> vo = new CoresJsonVo<>();
        vo.setFlag(flag);
        return vo;
    }

}
