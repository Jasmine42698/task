package com.layuiboot.controller;

import com.layuiboot.entry.IndenTity;
import com.layuiboot.entry.LoginUser;
import com.layuiboot.entry.SessionEntry;
import com.layuiboot.service.ISessionEntryService;
import com.layuiboot.utils.SessionUtill;
import com.layuiboot.vo.CoresJsonVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 *  登录业务
 * */

@RestController
public class LoginController {
    @Autowired
    private ISessionEntryService service;

    @Autowired
    private SessionUtill sessionUtill;


    /*
         SessionEntry(id=1, name=admin, password=123456, identity=admin, key=1)
    * */
    @PostMapping("/login")
    public Map<String,Boolean> login(@RequestBody LoginUser entry){
        //登录成功后，对象放进session域中，session行不通，使用cache缓存
        String identity = entry.getIdentity();
        SessionEntry sessionEntry = null;
        if (identity.equals(IndenTity.ADMIN)){
            sessionEntry = service.selectSessionEntry(IndenTity.ADMIN_TABLE,entry);
        } else if (identity.equals(IndenTity.STUDENT)) {
            sessionEntry = service.selectSessionEntry(IndenTity.STUDENT_TABLE,entry);
        }else {
            sessionEntry = service.selectSessionEntry(IndenTity.TEACHER_TABLE,entry);
        }
        //将对象放入cache缓存中
        sessionUtill.setSessionEntry(IndenTity.SESSIO_NENTRY,sessionEntry);
        boolean flag = sessionEntry != null ? true : false;
        Map<String,Boolean> map = new HashMap<>();
        map.put("flag",flag);
        return map;
    }

    /**
     * 因为，管理员，教师，学生都有修改密码，代码雷同，所以抽取到 LoginContrller 进行修改密码
     * 修改密码
     * */
    @PutMapping("/update")
    public CoresJsonVo<SessionEntry> updatePassword(@RequestParam("oldPassword")String oldPassword,
                                                    @RequestParam("password")String password){
        //缓存中取出管理员对象
        SessionEntry sessionEntry = sessionUtill.getSessionEntry(IndenTity.SESSIO_NENTRY);
        boolean flag = false;
        //与原密码相同则修改
        if (oldPassword.equals(sessionEntry.getPassword())){
            String tableName = "tu_lg_" + sessionEntry.getIdentity();
            flag = service.updatePasByid(tableName, password, sessionEntry.getId());
        }
        CoresJsonVo<SessionEntry> vo = new CoresJsonVo<>();
        vo.setFlag(flag);
        return vo;
    }
}
