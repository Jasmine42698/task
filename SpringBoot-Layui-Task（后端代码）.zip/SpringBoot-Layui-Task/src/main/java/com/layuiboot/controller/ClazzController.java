package com.layuiboot.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.layuiboot.entry.Clazz;
import com.layuiboot.service.IClazzService;
import com.layuiboot.vo.CoresJsonVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/clazz")
public class ClazzController {

    @Autowired
    private IClazzService clazzService;

    /**
     * 查所有
     * */
    @GetMapping
    public CoresJsonVo<Clazz> getClazzs(){
        List<Clazz> clazzs = clazzService.list();
        CoresJsonVo<Clazz> vo = new CoresJsonVo<>();
        vo.setFlag(clazzs.size() > 0);
        vo.setData(clazzs);
        return vo;
    }

    /**
     * 根据条件查询
     * */
    @GetMapping("/{name}")
    public CoresJsonVo<Clazz> getClazzByCondition(@PathVariable("name") String cname){
        QueryWrapper<Clazz> wrapper = new QueryWrapper<>();
        wrapper.eq("name",cname);
        List<Clazz> clazzs = clazzService.list(wrapper);
        CoresJsonVo<Clazz> vo = new CoresJsonVo<>();
        vo.setData(clazzs);
        vo.setFlag(clazzs.size() > 0);
        return vo;
    }

    /**
     * 删除
     * */
    @DeleteMapping("/{id}")
    public CoresJsonVo<Clazz> deleteByid(@PathVariable("id")Integer id){
        boolean flag = clazzService.deleteByclazzId(id);
        CoresJsonVo<Clazz> vo = new CoresJsonVo<>();
        vo.setFlag(flag);
        return vo;
    }

    /**
     * 添加
     * */
    @PostMapping
    public CoresJsonVo<Clazz> addClazz(@RequestBody Clazz clazz){
        boolean flag = clazzService.save(clazz);
        CoresJsonVo<Clazz> vo = new CoresJsonVo<>();
        vo.setFlag(flag);
        return vo;
    }

    /**
     * 修改
     * */
    @PutMapping
    public CoresJsonVo<Clazz> updateByid(@RequestBody Clazz clazz){
        boolean flag = clazzService.updateClazzById(clazz);
        CoresJsonVo<Clazz> vo = new CoresJsonVo<>();
        vo.setFlag(flag);
        return vo;
    }
}
