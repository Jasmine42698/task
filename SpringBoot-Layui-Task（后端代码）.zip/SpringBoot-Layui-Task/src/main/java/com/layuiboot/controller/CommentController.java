package com.layuiboot.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.layuiboot.entry.Comment;
import com.layuiboot.entry.IndenTity;
import com.layuiboot.service.ICommentService;
import com.layuiboot.utils.SessionUtill;
import com.layuiboot.vo.CoresJsonVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/comment")
public class CommentController {

    @Autowired
    private ICommentService commentService;

    /**/
    @Autowired
    private SessionUtill sessionUtill;

    /**/
    @PostMapping("/addComment")
    public boolean addComment(@RequestBody Comment comment){
        comment.setTeacher(sessionUtill.getSessionEntry(IndenTity.SESSIO_NENTRY).getName());
        return commentService.addComment(comment);
    }


    /**
     * 查所有
     * */
    @GetMapping
    public CoresJsonVo<Comment> getComments(){
        List<Comment> comments = commentService.list();
        CoresJsonVo<Comment> vo = new CoresJsonVo<>();
        vo.setFlag(comments.size() > 0);
        vo.setData(comments);
        return vo;
    }

    /**
     * 根据条件查询
     * */
    @GetMapping("/condition")
    public CoresJsonVo<Comment> getCommentsByCondition(@RequestParam("teacher")String teacher,
                                                       @RequestParam("student")String student,
                                                       @RequestParam("startScore")String startScore,
                                                       @RequestParam("endScore")String endScore){

        QueryWrapper<Comment> wrapper = new QueryWrapper<>();
        wrapper = teacher != "" ? wrapper.eq("teacher",teacher) : wrapper;
        wrapper = student != "" ? wrapper.eq("student",student) : wrapper;
        if (startScore != ""){
            wrapper.apply(startScore != "", "Score >= " + Double.parseDouble(startScore) );
        }
        if (endScore != ""){
            wrapper.apply(endScore != "", "Score <= " + Double.parseDouble(endScore));
        }
        List<Comment> comments = commentService.list(wrapper);
        CoresJsonVo<Comment> vo = new CoresJsonVo<>();
        vo.setFlag(comments.size() > 0);
        vo.setData(comments);
        return vo;
    }

    /**
     * 修改
     * */
    @PutMapping
    public CoresJsonVo<Comment> updateCommentById(@RequestParam("id")Integer id,
                                                  @RequestParam("score")Double score){
        boolean flag = commentService.updateCommentById(id, score);
        //也需要修改教师中对应的分数信息，这里没写
        CoresJsonVo<Comment> vo = new CoresJsonVo<>();
        vo.setFlag(flag);
        return vo;
    }

    /**
     * 删除
     * */
    @DeleteMapping("/{id}")
    public CoresJsonVo<Comment> removeCommentByid(@PathVariable("id")Integer id){
        boolean flag = commentService.removeById(id);
        //也需要删除教师中对应的信息，这里没写
        CoresJsonVo<Comment> vo = new CoresJsonVo<>();
        vo.setFlag(flag);
        return vo;
    }


}
