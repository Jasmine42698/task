package com.layuiboot.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.layuiboot.entry.*;
import com.layuiboot.service.impl.ClazzServiceImpl;
import com.layuiboot.service.impl.StudentServiceimpl;
import com.layuiboot.utils.LoadFileUtil;
import com.layuiboot.utils.SessionUtill;
import com.layuiboot.vo.CoresJsonVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;

/*
* 学生
* */
@RestController
@RequestMapping("/student")
@Slf4j
public class StudentController {

    @Autowired
    private StudentServiceimpl serviceimpl;

    @Autowired
    private ClazzServiceImpl clazzService;

    @Autowired
    private SessionUtill sessionUtill;

    /**
     * 分页查询
     * 这里其实不需要用分页查询，layui页面封装好了
     */
    @GetMapping
    public CoresJsonVo<Student> getStudents() {
        CoresJsonVo<Student> stuByPage = serviceimpl.getStuByPage(1, 10);
        return stuByPage;
    }

    /**
     * 根据条件查询
     */
    @GetMapping("/byQuery")
    public CoresJsonVo<Student> getStusByCondition(@RequestParam("stuId") String stuId,
                                                   @RequestParam("name") String name,
                                                   @RequestParam("sex") String sex,
                                                   @RequestParam("clazz") String clazzName) throws UnsupportedEncodingException {
        name = URLDecoder.decode(name, "utf-8");
        sex = URLDecoder.decode(sex, "utf-8");
        clazzName = URLDecoder.decode(clazzName, "utf-8");
        List<Student> students = serviceimpl.getByQuery(stuId, name, sex, clazzName);
        CoresJsonVo vo = new CoresJsonVo();
        vo.setFlag(true);
        vo.setData(students);
        return vo;
    }

    /**
     * 根据 班级id 查询学生
     * */
    @GetMapping("/{cName}")
    public CoresJsonVo<Student> getStusByCname(@PathVariable("cName") String clazzName) throws UnsupportedEncodingException {
        clazzName = URLDecoder.decode(clazzName, "utf-8");
        //学生表存的是班级的id，需要根据班级名称获取班级id
        QueryWrapper<Clazz> clazzWrapper = new QueryWrapper<>();
        clazzWrapper.eq("name",clazzName);
        Clazz clazz = clazzService.getOne(clazzWrapper);
        //根据条件查询学生
        List<Student> students = serviceimpl.getStuByCId(clazz.getCid());
        CoresJsonVo<Student> vo = new CoresJsonVo<>();
        vo.setFlag(true);
        vo.setData(students);
        return vo;
    }

    /**
     * 添加学生信息
     */
    @PostMapping
    public CoresJsonVo<Student> addStudent(@RequestBody Student student) {
        System.out.println(student);
        boolean flag = serviceimpl.saveStu(student);
        CoresJsonVo<Student> vo = new CoresJsonVo<>();
        vo.setFlag(flag);
        return vo;
    }

    /**
     * 修改学生信息
     * 第三步：项目整合时注意：这里业务层 updateByStuId 以及下面 代码有修改
     */
    @PutMapping
    public CoresJsonVo<Student> updateStudent(@RequestBody Student student) {
        Student stu = serviceimpl.getStuById(student.getId());
        // 删除原头像文件,头像文件名称不同才删除
        if (student.getHead() != "" && (!stu.getHead().equals(student.getHead()))){
            LoadFileUtil.deleteFile(stu.getHead());
        }
        //更新信息
        boolean flag = serviceimpl.updateByStuId(student);
        CoresJsonVo<Student> vo = new CoresJsonVo<>();
        vo.setFlag(flag);
        List<Student> studentList = new ArrayList<>();
        studentList.add(student);
        vo.setData(studentList);
        return vo;
    }

    /**
     * 删除学生信息
     */
    @DeleteMapping("/{id}")
    public CoresJsonVo<Student> removeStu(@PathVariable("id")Integer id){
        boolean flag = serviceimpl.removeById(id);
        System.out.println();
        CoresJsonVo<Student> vo = new CoresJsonVo<>();
        vo.setFlag(flag);
        return vo;
    }

    /**
     * 根据id查询学生信息,  用于前端个人信息页面信息
     * 第三步：项目整合： 加上这段代码
     * */
    @GetMapping("/byId")
    public CoresJsonVo<Student> getStuById(){
        //从缓存中取出对象，获取学生的id
        SessionEntry sessionEntry = sessionUtill.getSessionEntry(IndenTity.SESSIO_NENTRY);
        Integer id = sessionEntry.getKey();

        Student student = serviceimpl.getStuById(id);
        ArrayList<Student> stuList = new ArrayList<>();
        stuList.add(student);
        CoresJsonVo<Student> vo = new CoresJsonVo<>();
        vo.setFlag(student != null);
        vo.setData(stuList);
        return vo;
    }

}
