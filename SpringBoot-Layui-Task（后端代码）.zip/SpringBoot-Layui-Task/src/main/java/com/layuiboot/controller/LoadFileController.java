package com.layuiboot.controller;

import com.layuiboot.utils.LoadFileUtil;
import com.layuiboot.vo.LoadFileVo;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

/**
 * 用于上传文件
 * */

@RestController
public class LoadFileController {

    /**
     * 头像上传
     * */
    @PostMapping("/loadFile")
    public LoadFileVo loadImg(MultipartFile file) {
        //使用工具类上传文件
        String fileName = LoadFileUtil.loadFile(file);
        LoadFileVo fileVo = new LoadFileVo(fileName != "",fileName);
        return fileVo;
    }
}
