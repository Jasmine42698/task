package com.layuiboot.controller;

import com.alibaba.druid.sql.ast.statement.SQLColumnDefinition;
import com.layuiboot.entry.Admin;
import com.layuiboot.entry.IndenTity;
import com.layuiboot.entry.SessionEntry;
import com.layuiboot.service.IAdminService;
import com.layuiboot.service.ISessionEntryService;
import com.layuiboot.utils.LoadFileUtil;
import com.layuiboot.utils.SessionUtill;
import com.layuiboot.vo.CoresJsonVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

/*
* 管理员
* */
@RestController
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private IAdminService service;

    @Autowired
    private ISessionEntryService entryService;

    @Autowired
    private SessionUtill sessionUtill;

     /**
     * 查询信息
     * */
     @GetMapping
     public CoresJsonVo<Admin> getAdmin(){
         //从session中获取域对象，查信息
         SessionEntry sessionEntry = sessionUtill.getSessionEntry(IndenTity.SESSIO_NENTRY);
         /*
         SessionEntry(id=1, name=admin, password=123456, identity=admin, key=1)
         * */
         //缓存中的对象的 外键key 即为管理员的id
         Admin admin = service.getById(sessionEntry.getKey());
         CoresJsonVo<Admin> vo = new CoresJsonVo<>();
         ArrayList<Admin> admins = new ArrayList<>();
         admins.add(admin);
         vo.setFlag(admin != null);
         vo.setData(admins);
         return vo;
     }

     /**
     * 修改信息
     * */
     @PutMapping
     public CoresJsonVo<Admin> updateAdmin(@RequestBody Admin admin){
         //取出缓存中的对象
         SessionEntry sessionEntry = sessionUtill.getSessionEntry(IndenTity.SESSIO_NENTRY);
         //缓存中的对象的 外键key 即为管理员的id
         admin.setId(sessionEntry.getKey());
         //如果头像文件为空，不作修改
         if (admin.getHead() == ""){
             Admin admin1 = service.getById(sessionEntry.getKey());
             admin.setHead(admin1.getHead());
         }else {
             //删除原头像文件
             Admin admin1 = service.getById(sessionEntry.getKey());
             LoadFileUtil.deleteFile(admin1.getHead());
         }
         //这里应该在service层进行业务回滚，这里就不用了
         boolean flag = service.updateById(admin);
         sessionEntry.setName(admin.getName());
         boolean sesflag = entryService.updateSionById(IndenTity.ADMIN_TABLE,sessionEntry);

         //注意： 缓存中的sessionEntry 用户名也需要修改
         sessionEntry.setName(admin.getName());
         sessionUtill.setSessionEntry(IndenTity.SESSIO_NENTRY,sessionEntry);

         ArrayList<Admin> admins = new ArrayList<>();
         admins.add(admin);
         CoresJsonVo<Admin> vo = new CoresJsonVo<>();
         vo.setFlag(flag == sesflag);
         vo.setData(admins);
         return vo;
     };

}
