package com.layuiboot.vo;

import lombok.Data;

import java.util.List;

@Data
public class CoresJsonVo<T> {
    private String code;
    private boolean flag;
    private Integer count;
    private List<T> data;
}
