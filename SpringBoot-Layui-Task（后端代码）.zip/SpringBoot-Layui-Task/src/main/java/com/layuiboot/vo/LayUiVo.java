package com.layuiboot.vo;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class LayUiVo<T> {
    private Integer code = 200;
    private String msg ="";
    private Integer count = 1000;
    private List<T> data;

}
