package com.layuiboot.mapper;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.layuiboot.entry.Clazz;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ClazzMapperTest {

    @Autowired
    private ClazzMapper clazzMapper;

    @Test
    void testbyName(){
        QueryWrapper<Clazz> wrapper = new QueryWrapper<>();
        wrapper.eq("name", "高三3班");
        clazzMapper.selectList(wrapper);
    }
}
