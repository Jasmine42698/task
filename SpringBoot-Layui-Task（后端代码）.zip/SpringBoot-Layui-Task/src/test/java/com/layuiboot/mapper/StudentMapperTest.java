package com.layuiboot.mapper;

import com.layuiboot.entry.Clazz;
import com.layuiboot.entry.Student;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
@Slf4j
public class StudentMapperTest {

    @Autowired
    private StudentMapper mapper;

    @Test
    void testPageStu(){
        List<Student> students = mapper.selectAll();
        System.out.println(students);
    }

    @Test
    void testQuery(){
        List<Student> students = mapper.selectByQuery(null, "张三", "男", 3);
        System.out.println(students);
    }

    @Test
    void testupdateBystuId(){
       Student s = new Student(2,"200304", "王五", "0234.jpg", "男",
                                "123456",new Clazz(null,"高三2班"));
       int stuId = mapper.updateByStuId(s);
       System.out.println(stuId);
    }

}
