package com.layuiboot.service;

import com.layuiboot.entry.Task;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

@SpringBootTest
public class TaskServiceImplTest {

    @Autowired
    private ITaskService service;

    @Test
    void insert() throws ParseException {
        Date d = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String startTime = sdf.format(d);

        for (int i = 0; i < 5; i++) {
            Task task = new Task(null,"今天下雨吗？","无要求",
                    startTime,startTime,"teacher1","高三4班");
            service.save(task);
        }
    }
}
