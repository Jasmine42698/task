package com.layuiboot.service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.layuiboot.entry.Teacher;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
public class TeacherServiceImplTest {
    @Autowired
    private ITeacherService teacherService;

    @Test
    void getAll(){
        List<Teacher> teachers = teacherService.list();
    }

    @Test
    void get(){
        QueryWrapper<Teacher> wrapper = new QueryWrapper<>();
        wrapper.eq("name","teacher1");
        wrapper.eq("clazz","高三2班");
        List<Teacher> teachers = teacherService.list(wrapper);
    }

    @Test
    void delete(){
        boolean flag = teacherService.removeById(1);
    }

    @Test
    void update(){
        Teacher teacher = new Teacher();
        boolean flag = teacherService.updateById(teacher);
    }

    @Test
    void add(){
//        for (int i = 0; i < 5; i++) {
//            Teacher teacher = new Teacher(null,"teacher1","男",30,
//                    "111.png","112112","@qq.com111","高三" + i  + "班");
//            boolean flag = teacherService.save(teacher);
//        }
        Teacher teacher = new Teacher();
        boolean flag = teacherService.save(teacher);
    }

}
