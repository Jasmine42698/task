
package com.layuiboot.service;

import com.github.pagehelper.PageHelper;
import com.layuiboot.entry.Clazz;
import com.layuiboot.entry.Student;
import com.layuiboot.service.impl.StudentServiceimpl;
import com.layuiboot.vo.CoresJsonVo;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@SpringBootTest
@Slf4j
@Transactional
public class StudentServiceImplTest {

    @Autowired
    private StudentServiceimpl serviceimpl;

    @Test
    void getStudents(){
        CoresJsonVo<Student> stuByPage = serviceimpl.getStuByPage(1, 1);
        log.info("学生集合",stuByPage);
    }

    @Test
    void testPages(){
        CoresJsonVo<Student> vo = serviceimpl.getStuByPage(2, 5);
        log.info("json",vo);
    }


    @Test
    void testUpdateByStuId(){
        Student s = new Student(2,"200304", "王五", "0234.jpg", "男",
                "123456",new Clazz(null,"高三3班"));
        boolean flag = serviceimpl.updateByStuId(s);
        System.out.println(flag);
    }

    @Test
    void testInsertstu(){
        Student s = new Student(null,"200304", "王五", "", "男",
                "123456",new Clazz(null,"高三2班"));
        boolean flag = serviceimpl.saveStu(s);
        System.out.println(flag);
    }

}
