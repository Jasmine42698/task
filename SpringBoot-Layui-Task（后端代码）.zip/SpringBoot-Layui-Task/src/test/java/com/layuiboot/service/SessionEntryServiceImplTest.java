package com.layuiboot.service;

import com.layuiboot.entry.LoginUser;
import com.layuiboot.entry.SessionEntry;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class SessionEntryServiceImplTest {
    @Autowired
    private ISessionEntryService service;

    @Test
    void testSelectSeionEntry(){
        LoginUser entry = new LoginUser();
        entry.setUserName("admin");
        entry.setPassword("123456");
        SessionEntry sessionEntry = service.selectSessionEntry("tu_lg_teacher", entry);
        System.out.println(sessionEntry);
    }
}
