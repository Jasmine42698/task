package com.layuiboot.service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.layuiboot.entry.Comment;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
public class CommentServiceImplTest {

    @Autowired
    private ICommentService commentService;

    @Test
    void testGetConments(){
        List<Comment> list = commentService.list();
    }

    @Test
    void testdelete(){
        boolean flag = commentService.removeById(2);
    }

    @Test
    void testupdate(){
        commentService.updateCommentById(1,78.0);
    }

    @Test
    void insert(){
        for (int i = 1; i < 8; i++) {
            Comment c = new Comment(null,"teacher" + i,"1 + "+i+" = ?",
                    "student"+ i,78.0, "无");
            commentService.save(c);
        }


    }

    @Test
    void testGetConmentsByCondition(){
        QueryWrapper<Comment> wrapper = new QueryWrapper<>();
        wrapper.eq("teacher","teacher1");
        wrapper.eq("student","student1");
        double startScore = 20;
        double endScore = 80;
        wrapper.apply(startScore != 0,
                        "Score >= " + startScore)
                .apply(endScore != 0,
                        "Score <= " + endScore);
        List<Comment> comments = commentService.list(wrapper);
    }
}
