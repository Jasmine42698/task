package com.layuiboot.service;

import com.layuiboot.entry.TaskSubmit;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class TaskUbmitServiceImplTest {

    @Autowired
    private ITaskSubmitService submitService;

    @Test
    void insertTest(){

        for (int i = 4; i < 9; i++) {
            TaskSubmit taskSubmit = new TaskSubmit(null, "1+1 = ？","写出计算过程",
                    "teache" + i,"高三6班",
                    "2024-06-22 09:56:39","2024-06-22 09:56:39",
                    "200304" + i,"student" + i,"无","未提交");
            submitService.save(taskSubmit);
        }

    }
}
