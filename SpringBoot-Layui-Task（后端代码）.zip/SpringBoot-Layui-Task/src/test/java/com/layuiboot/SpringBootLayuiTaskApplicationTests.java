package com.layuiboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootLayuiTaskApplicationTests {

    @Test
    void contextLoads() {
    }

}
